f = open('corpus.txt','r')
g = open('topics.txt','r')
h = open('topicalPhrases.txt','w')
phrases = [{} for i in range(100)]
for line in f:
    line = line.strip().split(',')
    topics = g.readline().split(',')
    for i in range(len(line)):
        topic = topics[i]
        phrase = line[i]
        phrase = phrase.split(" ")
        #greater than 1 means phrase == 1 means unigram
        if len(phrase) > 1:
            phrase = tuple(phrase)
            if phrase in phrases[int(topic)]:
                phrases[int(topic)][phrase]+=1
            else:
                phrases[int(topic)][phrase]=1

all_list = []
for topic in range(len(phrases)):

    list = []
    if len(phrases[topic])>0:
        top = []
        for cand in phrases[topic]:
            top.append((cand, phrases[topic][cand]))
        top.sort(key=lambda x: x[1], reverse=True)
        for i in range(min(50000000, len(top))):
            cand = top[i]
            word = "_".join(cand[0])
            list.append(word)
    if len(list) > 0:
        all_list.append(list[0:10])
h.write(str(all_list))



